/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package abstractcompany;

/**
 *
 * @author Bryce Philbert M. Salvador <bpmsalvador at addu.edu.ph>
 */
public interface Company {
    public String getCname();

    public void setCname(String Cname);

    public String getCaddress();

    public void setCaddress(String Caddress);

    public String getCcontact();

    public void setCcontact(String Ccontact);

    public String getCemail();

    public void setCemail(String Cemail);
}
